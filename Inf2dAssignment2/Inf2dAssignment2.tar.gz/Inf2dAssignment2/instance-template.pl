% ---------------------------------------------------------------------
%  ----- Informatics 2D - 2011/12 - Second Assignment - Planning -----
% ---------------------------------------------------------------------
%
% Write here you matriculation number (only - your name is not needed)
% Matriculation Number: s_______
%
%
% ------------------------- Problem Instance --------------------------
% This file is a template for a problem instance: the definition of an
% initial state and of a goal. 

% debug(on).	% need additional debug information at runtime?



% --- Load domain definitions from an external file -------------------

:- [domain-template].		% Replace with the domain for this problem




% --- Definition of the initial state ---------------------------------






% --- Goal condition that the planner will try to reach ---------------

goal(S) :-					% fill in the goal definition




% ---------------------------------------------------------------------
% ---------------------------------------------------------------------
